package com.cg.monika.junit;

public interface Greeting {
	String greet(String name);
}
