package com.cg.monika;

public interface Greeting {
	
	String greet(String name);

}
